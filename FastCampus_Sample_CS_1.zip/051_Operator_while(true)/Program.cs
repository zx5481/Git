﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*-----------------------------------------------------------------------------
 * Name: _051_Operator_while(true)
 * DESC: 중첩 for
-----------------------------------------------------------------------------*/
namespace _051_Operator_while_true_
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                Console.WriteLine("while(true)"); //무한으로 실행..
            }
        }
    }
}
