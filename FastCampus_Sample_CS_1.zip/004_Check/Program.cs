﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _004_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("다양한 출력");
            Console.WriteLine("해보기");

            Console.WriteLine("{0} * {1} = {2}", 2, 10, 200);

            Console.WriteLine("    *    ");
            Console.WriteLine("   ***   ");
            Console.WriteLine("  *****  ");

            Console.ReadKey();
        }
    }
}
