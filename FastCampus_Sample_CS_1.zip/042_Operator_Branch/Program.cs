﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*-----------------------------------------------------------------------------
 * Name: _042_Operator_Branch
 * DESC: if(조건문): 조건문이 가지는 값은 true/false 기초
-----------------------------------------------------------------------------*/
namespace _042_Operator_Branch
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isBool = false;

            if(isBool) //조건문이 가니는 값은(true/false)
            {
                Console.WriteLine("isBool:  {0}", isBool);
            }
            else
            {
                Console.WriteLine("isBool:  {0}", isBool);
            }
        }
    }
}
